export CUDA_VISIBLE_DEVICES=0


model_name=Autocorr_Nonstationary_Transformer

python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/battery/ \
  --data_path NASA \
  --target capacity \
  --model_id NASA_16_16 \
  --model $model_name \
  --data NASA \
  --features MS \
  --seq_len 16 \
  --label_len 8 \
  --pred_len 16 \
  --e_layers 1 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 6 \
  --dec_in 6 \
  --c_out 6 \
  --des 'Exp' \
  --itr 1 \
  --p_hidden_dims 128 128 \
  --p_hidden_layers 2\
  --d_model 128\
  --train_epochs 10

python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/battery/ \
  --data_path NASA \
  --target capacity \
  --model_id NASA_16_16 \
  --model $model_name \
  --data NASA \
  --features MS \
  --seq_len 16 \
  --label_len 8 \
  --pred_len 16 \
  --e_layers 2 \
  --d_layers 2 \
  --factor 3 \
  --enc_in 6 \
  --dec_in 6 \
  --c_out 6 \
  --des 'Exp' \
  --itr 1 \
  --p_hidden_dims 128 128 \
  --p_hidden_layers 2\
  --d_model 128\
  --train_epochs 10

python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/battery/ \
  --data_path NASA \
  --target capacity \
  --model_id NASA_16_16 \
  --model $model_name \
  --data NASA \
  --features MS \
  --seq_len 16 \
  --label_len 8 \
  --pred_len 16 \
  --e_layers 3 \
  --d_layers 3 \
  --factor 3 \
  --enc_in 6 \
  --dec_in 6 \
  --c_out 6 \
  --des 'Exp' \
  --itr 1 \
  --p_hidden_dims 128 128 \
  --p_hidden_layers 2\
  --d_model 128\
  --train_epochs 10


























python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/battery/ \
  --data_path NASA \
  --target capacity \
  --model_id NASA_16_16 \
  --model $model_name \
  --data NASA \
  --features MS \
  --seq_len 16 \
  --label_len 8 \
  --pred_len 16 \
  --e_layers 1 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 6 \
  --dec_in 6 \
  --c_out 6 \
  --des 'Exp' \
  --itr 1 \
  --p_hidden_dims 128 128 \
  --p_hidden_layers 2\
  --d_model 64\
  --train_epochs 10

python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/battery/ \
  --data_path NASA \
  --target capacity \
  --model_id NASA_16_16 \
  --model $model_name \
  --data NASA \
  --features MS \
  --seq_len 16 \
  --label_len 8 \
  --pred_len 16 \
  --e_layers 2 \
  --d_layers 2 \
  --factor 3 \
  --enc_in 6 \
  --dec_in 6 \
  --c_out 6 \
  --des 'Exp' \
  --itr 1 \
  --p_hidden_dims 128 128 \
  --p_hidden_layers 2\
  --d_model 64\
  --train_epochs 10

python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/battery/ \
  --data_path NASA \
  --target capacity \
  --model_id NASA_16_16 \
  --model $model_name \
  --data NASA \
  --features MS \
  --seq_len 16 \
  --label_len 8 \
  --pred_len 16 \
  --e_layers 3 \
  --d_layers 3 \
  --factor 3 \
  --enc_in 6 \
  --dec_in 6 \
  --c_out 6 \
  --des 'Exp' \
  --itr 1 \
  --p_hidden_dims 128 128 \
  --p_hidden_layers 2\
  --d_model 64\
  --train_epochs 10













































python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/battery/ \
  --data_path NASA \
  --target capacity \
  --model_id NASA_16_16 \
  --model $model_name \
  --data NASA \
  --features MS \
  --seq_len 16 \
  --label_len 8 \
  --pred_len 16 \
  --e_layers 1 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 6 \
  --dec_in 6 \
  --c_out 6 \
  --des 'Exp' \
  --itr 1 \
  --p_hidden_dims 128 128 \
  --p_hidden_layers 2\
  --d_model 32\
  --train_epochs 10

python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/battery/ \
  --data_path NASA \
  --target capacity \
  --model_id NASA_16_16 \
  --model $model_name \
  --data NASA \
  --features MS \
  --seq_len 16 \
  --label_len 8 \
  --pred_len 16 \
  --e_layers 2 \
  --d_layers 2 \
  --factor 3 \
  --enc_in 6 \
  --dec_in 6 \
  --c_out 6 \
  --des 'Exp' \
  --itr 1 \
  --p_hidden_dims 128 128 \
  --p_hidden_layers 2\
  --d_model 32\
  --train_epochs 10

python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/battery/ \
  --data_path NASA \
  --target capacity \
  --model_id NASA_16_16 \
  --model $model_name \
  --data NASA \
  --features MS \
  --seq_len 16 \
  --label_len 8 \
  --pred_len 16 \
  --e_layers 3 \
  --d_layers 3 \
  --factor 3 \
  --enc_in 6 \
  --dec_in 6 \
  --c_out 6 \
  --des 'Exp' \
  --itr 1 \
  --p_hidden_dims 128 128 \
  --p_hidden_layers 2\
  --d_model 32\
  --train_epochs 10
































python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/battery/ \
  --data_path NASA \
  --target capacity \
  --model_id NASA_16_16 \
  --model $model_name \
  --data NASA \
  --features MS \
  --seq_len 16 \
  --label_len 8 \
  --pred_len 16 \
  --e_layers 1 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 6 \
  --dec_in 6 \
  --c_out 6 \
  --des 'Exp' \
  --itr 1 \
  --p_hidden_dims 128 128 \
  --p_hidden_layers 2\
  --d_model 16\
  --train_epochs 10

python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/battery/ \
  --data_path NASA \
  --target capacity \
  --model_id NASA_16_16 \
  --model $model_name \
  --data NASA \
  --features MS \
  --seq_len 16 \
  --label_len 8 \
  --pred_len 16 \
  --e_layers 2 \
  --d_layers 2 \
  --factor 3 \
  --enc_in 6 \
  --dec_in 6 \
  --c_out 6 \
  --des 'Exp' \
  --itr 1 \
  --p_hidden_dims 128 128 \
  --p_hidden_layers 2\
  --d_model 16\
  --train_epochs 10

python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/battery/ \
  --data_path NASA \
  --target capacity \
  --model_id NASA_16_16 \
  --model $model_name \
  --data NASA \
  --features MS \
  --seq_len 16 \
  --label_len 8 \
  --pred_len 16 \
  --e_layers 3 \
  --d_layers 3 \
  --factor 3 \
  --enc_in 6 \
  --dec_in 6 \
  --c_out 6 \
  --des 'Exp' \
  --itr 1 \
  --p_hidden_dims 128 128 \
  --p_hidden_layers 2\
  --d_model 16\
  --train_epochs 10