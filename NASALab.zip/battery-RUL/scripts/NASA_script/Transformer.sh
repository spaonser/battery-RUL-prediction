export CUDA_VISIBLE_DEVICES=0


model_name=Transformer

python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/battery/ \
  --data_path NASA \
  --target capacity \
  --model_id NASA_16_16 \
  --model $model_name \
  --data NASA \
  --features MS \
  --seq_len 16 \
  --label_len 8 \
  --pred_len 16 \
  --e_layers 2 \
  --d_layers 2 \
  --factor 3 \
  --enc_in 6 \
  --dec_in 6 \
  --c_out 6 \
  --des 'Exp' \
  --itr 1 \
  --d_model 64\
  --train_epochs 10
