export CUDA_VISIBLE_DEVICES=0


model_name=RNN

python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/battery/ \
  --data_path CALCE \
  --target capacity \
  --model_id CALCE_16_16 \
  --model $model_name \
  --data CALCE \
  --features MS \
  --seq_len 16 \
  --label_len 8 \
  --pred_len 16 \
  --e_layers 2 \
  --d_layers 2 \
  --factor 3 \
  --enc_in 6 \
  --dec_in 6 \
  --c_out 6 \
  --des 'Exp' \
  --itr 1 \
  --d_model 128\
  --train_epochs 2
