import numpy as np


def RSE(pred, true):
    return np.sqrt(np.sum((true - pred) ** 2)) / np.sqrt(np.sum((true - true.mean()) ** 2))


def CORR(pred, true):
    u = ((true - true.mean(0)) * (pred - pred.mean(0))).sum(0)
    d = np.sqrt(((true - true.mean(0)) ** 2 * (pred - pred.mean(0)) ** 2).sum(0))
    return (u / d).mean(-1)


def MAE(pred, true):
    return np.mean(np.abs(pred - true))


def MSE(pred, true):
    return np.mean((pred - true) ** 2)


def RMSE(pred, true):
    return np.sqrt(MSE(pred, true))


def MAPE(pred, true):
    return np.mean(np.abs((pred - true) / true))


def MSPE(pred, true):
    return np.mean(np.square((pred - true) / true))


def RE(pred, true, threshold):
    pred_length = pred.shape[1]
    pred_sr = []
    true_sr = []
    for i in range(len(pred)-1):
        pred_sr.append(pred[i][0][0])
        true_sr.append(true[i][0][0])
    for j in range(pred_length):
        pred_sr.append(pred[-1][j][0])
        true_sr.append(true[-1][j][0])

    pred_sr = np.array(pred_sr)
    true_sr = np.array(true_sr)

    true_re, pred_re = len(true_sr), len(pred_sr)
    for i in range(len(true_sr) - 1):
        if true_sr[i] <= threshold >= true_sr[i + 1]:
            true_re = i - 1 + pred_length
            break
    for i in range(len(pred_sr) - 1):
        if pred_sr[i] <= threshold:
            pred_re = i - 1 + pred_length
            break

    diff = abs(true_re - pred_re)
    # print("check the generated series: pred_series:{}\ntrue_series:{}".format(pred_sr, true_sr))
    # print("check the RUL result: pred_re:{}, true_re{}".format(pred_re, true_re))
    return diff / true_re if diff != 0 else 1 / true_re


def RE_last_point(pred, true, threshold):
    pred_length = pred.shape[1]
    pred_sr = []
    true_sr = []
    for j in range(pred_length):
        pred_sr.append(pred[0][j][0])
        true_sr.append(true[0][j][0])
    for i in range(len(pred)-1):
        pred_sr.append(pred[i+1][-1][0])
        true_sr.append(true[i+1][-1][0])

    pred_sr = np.array(pred_sr)
    true_sr = np.array(true_sr)

    true_re, pred_re = len(true_sr), len(pred_sr)
    for i in range(len(true_sr) - 1):
        if true_sr[i] <= threshold >= true_sr[i + 1]:
            true_re = i - 1 + pred_length
            break
    for i in range(len(pred_sr) - 1):
        if pred_sr[i] <= threshold:
            pred_re = i - 1 + pred_length
            break

    diff = abs(true_re - pred_re)
    # print("check the generated series by last point: pred_series:{}\ntrue_series:{}".format(pred_sr, true_sr))
    # print("check the RUL result by last point: pred_re:{}, true_re{}".format(pred_re, true_re))
    return diff / true_re if diff != 0 else 1 / true_re


def RE_avg(pred, true, threshold):
    pred_length = pred.shape[1]
    pred_sr = []
    true_sr = []

    # form the true series
    for j in range(pred_length):
        true_sr.append(true[0][j][0])
    for i in range(len(pred)-1):
        true_sr.append(true[i+1][-1][0])

    # form the pred series
    pred_points = []
    for k in range(len(pred) + pred_length - 1):
        pred_points.append([])
    for k in range(len(pred)):
        for l in range(pred_length):
            pred_points[k+l].append(pred[k][l][0])

    for t in range(len(pred_points)):
        pred_point = np.array(pred_points[t])
        pred_sr.append(np.mean(pred_point))

    pred_sr = np.array(pred_sr)
    true_sr = np.array(true_sr)

    true_re, pred_re = len(true_sr), len(pred_sr)
    for i in range(len(true_sr) - 1):
        if true_sr[i] <= threshold >= true_sr[i + 1]:
            true_re = i - 1 + pred_length
            break
    for i in range(len(pred_sr) - 1):
        if pred_sr[i] <= threshold:
            pred_re = i - 1 + pred_length
            break

    diff = abs(true_re - pred_re)
    print("check the generated series by avg: pred_series:{}\ntrue_series:{}".format(pred_sr, true_sr))
    print("check the RUL result by avg: pred_re:{}, true_re{}".format(pred_re, true_re))
    return diff / true_re if diff != 0 else 1 / true_re


def metric(pred, true, threshold):
    mae = MAE(pred, true)
    mse = MSE(pred, true)
    rmse = RMSE(pred, true)
    mape = MAPE(pred, true)
    mspe = MSPE(pred, true)
    re = RE(pred, true, threshold)
    re_last_point = RE_last_point(pred, true, threshold)
    re_avg = RE_avg(pred, true, threshold)

    return mae, mse, rmse, mape, mspe, re, re_last_point, re_avg
